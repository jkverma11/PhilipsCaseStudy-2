﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StaticAnalyzerTool
{
    class CoverityAnalyzer : IStaticAnalyzer
    {
        public void ProcessInput(Paths projFilePath)
        {
            throw new NotImplementedException();
        }

        public void ProcessOutput()
        {
            throw new NotImplementedException();
        }
    }
}
